from django.urls import path
from . import views
from rest_framework.authtoken.views import obtain_auth_token # type: ignore

urlpatterns = [
    # Author
    path('authors/', views.author_list_create),
    path('authors/<int:pk>/', views.author_detail),

    # Category
    path('categories/', views.category_list_create),
    path('categories/<int:pk>/', views.category_detail),

    # Publisher
    path('publishers/', views.publisher_list_create),
    path('publishers/<int:pk>/', views.publisher_detail),

    # Book
    path('books/', views.book_list_create),
    path('books/<int:pk>/', views.book_detail),

    # Member
    path('members/', views.member_list_create),
    path('members/<int:pk>/', views.member_detail),

    # Borrow
    path('borrows/', views.borrow_list_create),
    path('borrows/<int:pk>/', views.borrow_detail),

    # Librarian
    path('librarians/', views.librarian_list_create),
    path('librarians/<int:pk>/', views.librarian_detail),

    # Reservation
    path('reservations/', views.reservation_list_create),
    path('reservations/<int:pk>/', views.reservation_detail),

  
]
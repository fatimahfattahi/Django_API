from django.contrib import admin
from .models import Author, Category, Publisher, Book, Member, Borrow, Librarian, Reservation

admin.site.register(Author)
admin.site.register(Category)
admin.site.register(Publisher)
admin.site.register(Book)
admin.site.register(Member)
admin.site.register(Borrow)
admin.site.register(Librarian)
admin.site.register(Reservation)
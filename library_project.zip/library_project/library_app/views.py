from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Author, Category, Publisher, Book, Member, Borrow, Librarian, Reservation
from .serializers import *

# --- Author Views ---
@api_view(['GET', 'POST'])
def author_list_create(request):
    if request.method == 'GET':
        authors = Author.objects.all()
        serializer = AuthorSerializer(authors, many=True)
        return Response(serializer.data)
    elif request.method == 'POST':
        serializer = AuthorSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)

@api_view(['GET', 'PUT', 'DELETE'])
def author_detail(request, pk):
    try:
        author = Author.objects.get(pk=pk)
    except Author.DoesNotExist:
        return Response(status=404)

    if request.method == 'GET':
        serializer = AuthorSerializer(author)
        return Response(serializer.data)
    elif request.method == 'PUT':
        serializer = AuthorSerializer(author, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=400)
    elif request.method == 'DELETE':
        author.delete()
        return Response(status=204)

# --- باقي الجداول بنفس الشكل ---

def generate_crud(model_class, serializer_class):
    @api_view(['GET', 'POST'])
    def list_create(request):
        if request.method == 'GET':
            items = model_class.objects.all()
            serializer = serializer_class(items, many=True)
            return Response(serializer.data)
        elif request.method == 'POST':
            serializer = serializer_class(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=201)
            return Response(serializer.errors, status=400)
    return list_create

def generate_detail(model_class, serializer_class):
    @api_view(['GET', 'PUT', 'DELETE'])
    def detail(request, pk):
        try:
            item = model_class.objects.get(pk=pk)
        except model_class.DoesNotExist:
            return Response(status=404)

        if request.method == 'GET':
            serializer = serializer_class(item)
            return Response(serializer.data)
        elif request.method == 'PUT':
            serializer = serializer_class(item, data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(serializer.errors, status=400)
        elif request.method == 'DELETE':
            item.delete()
            return Response(status=204)
    return detail

# Category
category_list_create = generate_crud(Category, CategorySerializer)
category_detail = generate_detail(Category, CategorySerializer)

# Publisher
publisher_list_create = generate_crud(Publisher, PublisherSerializer)
publisher_detail = generate_detail(Publisher, PublisherSerializer)

# Book
book_list_create = generate_crud(Book, BookSerializer)
book_detail = generate_detail(Book, BookSerializer)

# Member
member_list_create = generate_crud(Member, MemberSerializer)
member_detail = generate_detail(Member, MemberSerializer)

# Borrow
borrow_list_create = generate_crud(Borrow, BorrowSerializer)
borrow_detail = generate_detail(Borrow, BorrowSerializer)

# Librarian
librarian_list_create = generate_crud(Librarian, LibrarianSerializer)
librarian_detail = generate_detail(Librarian, LibrarianSerializer)

# Reservation
reservation_list_create = generate_crud(Reservation, ReservationSerializer)
reservation_detail = generate_detail(Reservation, ReservationSerializer)